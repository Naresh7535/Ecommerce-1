const express = require("express");
const app = express();
const port = 3000;

// Serve static files from public folder
app.use(express.static("public"));

app.get("/hello", (req, res) => {
  res.json("CS IS FUN@!")
})

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
